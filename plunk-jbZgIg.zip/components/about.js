angular.module('hello').component('about', {
  template:  '<h3>Its the UI-Router "Hello Galaxy" app!</h3>'
})